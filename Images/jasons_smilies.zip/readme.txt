Jason's Smiley Collection
=========================

The smilies in this collection have come from a variety of sources. Some have been downloaded from sites across the Internet, some are heavily modified versions of readily available smilies, and others have been created from scratch. All of them have been altered to make "sets" of smilies, each with the same colour, shape, style and size.

You may use these smilies as you wish for non-commercial purposes provided they remain unaltered, all other use of these smilies is prohibited without written permission from the author. If you intend making them available to others using some kind of index page, please include an acknowledgement and link to Jason's Smiley Collection somewhere on that page. Use of these smilies indicates acceptance of these terms.

If you have any comments or suggestions and would like to contact me, my email address is jason@bhra.org.uk.